/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividadepa2;

/**
 *
 * @author Admin
 */

import java.util.Scanner;


public class AtividadePA2 {

    public static void main(String[] args) {
      
        Scanner scanner = new Scanner(System.in);
        
        // Verificar idade
        System.out.println ("Digite sua idade: ");
        int idade = scanner.nextInt();
        if (idade > 21) {
            System.out.println("A pessoa tem mais de 21 anos.");
        } else {
            System.out.println("A pessoa tem 21 anos ou menos.");
        }
        
         // Verificar salário
        System.out.println ("Digite seu salário: ");
        double salario = scanner.nextDouble();
        double salarioMinimo = 1320; // Valor do salário mínimo atualizado
        if (salario > 5 * salarioMinimo) {
            System.out.println("O salário é maior que 5 vezes o salário mínimo.");
        } else {
            System.out.println("O salário é menor ou igual a 5 vezes o salário mínimo.");
        }
        
        //Verificar altura
        System.out.println("Digite sua altura em metros: ");
        double altura = scanner.nextDouble();
        if (altura > 1.75) {
            System.out.println("A altura é maior que 1,75 m.");
        } else {
            System.out.println("A altura é 1,75 m ou menor.");
        }
        
        // Verificar peso
        System.out.println("Digite seu peso em kg: ");
        double peso = scanner.nextDouble();
        if (peso > 70) {
            System.out.println("O peso é maior que 70 kg.");
        } else {
            System.out.println("O peso é 70 kg ou menor.");
        }
        
        // Verificar sobrenome
        System.out.println("Digite seu sobrenome: ");
        scanner.nextLine();  // Limpa o buffer do teclado
        String sobrenome = scanner.nextLine();
        String meuSobrenome = "Silva"; // Troque pelo seu sobrenome
        if (!sobrenome.equals(meuSobrenome)) {
            System.out.println("O sobrenome é diferente do meu.");
        } else {
            System.out.println("O sobrenome é igual ao meu.");
        }
        
        // Verificar gênero
        System.out.print("Digite seu gênero (f/m): ");
        char genero = scanner.next().charAt(0);
        if (genero == 'f') {
            System.out.println("O gênero é feminino.");
        } else {
            System.out.println("O gênero não é feminino.");
        }
        
        scanner.close();
    }
}
