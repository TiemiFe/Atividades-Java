/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividadepa3;

/**
 *
 * @author Admin
 */
import java.util.Scanner;

public class AtividadePA3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Informações Minhas
        String meuNome = "Fernanda";
        int minhaIdade = 20;
        double meuPeso = 51;
        double minhaAltura = 1.71;
        String minhaSerieFavorita = "Monk: Um Detetive Diferente";
        String minhaMusicaFavorita = "Praia de Morigasaki";
        String meuJogoFavorito = "Genshin Impact";
        
        // Ler informações da pessoa
        System.out.println("Digite seu nome: ");
        String nome = scanner.nextLine();
        System.out.println("Digite sua idade: ");
        int idade = scanner.nextInt();
        System.out.println("Digite seu peso: ");
        double peso = scanner.nextDouble();
        System.out.println("Digite sua altura: ");
        double altura = scanner.nextDouble();
        scanner.nextLine(); // Limpar o buffer
        System.out.println("Digite sua série favorita: ");
        String serieFavorita = scanner.nextLine();
        System.out.println("Digite sua música favorita: ");
        String musicaFavorita = scanner.nextLine();
        System.out.println("Digite seu jogo favorito: ");
        String jogoFavorito = scanner.nextLine();
        
        // Comparações
        int caracteristicasIguais = 0;

        if (nome.equals(meuNome)) {
            System.out.println("Pessoa com nome igual.");
            caracteristicasIguais++;
        } else {
            System.out.println("Pessoa com nome diferente.");
        }

        if (idade == minhaIdade) {
            System.out.println("Pessoa com idade igual.");
            caracteristicasIguais++;
        } else {
            System.out.println("Pessoa com idade diferente.");
        }

        if (peso == meuPeso) {
            System.out.println("Pessoa com peso igual.");
            caracteristicasIguais++;
        } else {
            System.out.println("Pessoa com peso diferente.");
        }

        if (altura == minhaAltura) {
            System.out.println("Pessoa com altura igual.");
            caracteristicasIguais++;
        } else {
            System.out.println("Pessoa com altura diferente.");
        }

        if (serieFavorita.equals(minhaSerieFavorita)) {
            System.out.println("Pessoa com série favorita igual.");
            caracteristicasIguais++;
        } else {
            System.out.println("Pessoa com série favorita diferente.");
        }

        if (musicaFavorita.equals(minhaMusicaFavorita)) {
            System.out.println("Pessoa com música favorita igual.");
            caracteristicasIguais++;
        } else {
            System.out.println("Pessoa com música favorita diferente.");
        }

        if (jogoFavorito.equals(meuJogoFavorito)) {
            System.out.println("Pessoa com jogo favorito igual.");
            caracteristicasIguais++;
        } else {
            System.out.println("Pessoa com jogo favorito diferente.");
        }

        // IF aninhado para verificar se há 3 ou mais características iguais
        if (caracteristicasIguais >= 3) {
            System.out.println("Esta pessoa é bem parecida comigo!");
        } else {
            System.out.println("Esta pessoa não tem muitas coisas em comum comigo.");
        }
        
        scanner.close();

    }
}
